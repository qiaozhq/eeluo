<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="/Public/images/favicon.ico">
    <link rel="Bookmark" href="/Public/images/favicon.ico">
    <title>e络工作室-后台管理系统</title>
    <!-- Bootstrap Core CSS -->
    <link href="/Public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/Public/css/admin/sb-admin.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="/Public/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/Public/css/admin/common.css" />
    <link rel="stylesheet" href="/Public/css/party/bootstrap-switch.css" />
    <link rel="stylesheet" type="text/css" href="/Public/css/party/uploadify.css">

    <!-- jQuery -->
    <script src="/Public/js/jquery.min.js"></script>
    <script src="/Public/js/bootstrap.min.js"></script>
    <script src="/Public/js/dialog/layer.js"></script>
    <script src="/Public/js/dialog.js"></script>
    <script type="text/javascript" src="/Public/js/party/jquery.uploadify.js"></script>

</head>

    



<body>
<div id="wrapper">

  <!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    
    <a class="navbar-brand" >e络工作室-官网后台</a>
  </div>
  <!-- Top Menu Items -->
  <ul class="nav navbar-right top-nav">
    
    
    <li class="dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo getLoginUsername()?> <b class="caret"></b></a>
      <ul class="dropdown-menu">
        <li>
          <a href="/adminuser/per.htm"><i class="fa fa-fw fa-user"></i> 个人中心</a>
        </li>
        <li class="divider"></li>
        <li>
          <a href="/adminuser/pas.htm"><i class="fa fa-fw fa-user"></i> 修改密码</a>
        </li>       
        <li class="divider"></li>
        <li>
          <a href="/login/loginout.htm"><i class="fa fa-fw fa-power-off"></i> 退出</a>
        </li>
      </ul>
    </li>
  </ul>
  <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
  <div class="collapse navbar-collapse navbar-ex1-collapse">
     <ul class="nav navbar-nav side-nav nav_list">
      <li <?php echo setActive('basic');?> >
        <a href="/basic.htm"><i class="fa fa-fw fa-bar-chart-o"></i> 基本管理</a>
      </li>
      <li <?php echo setActive('menu');?> >
        <a href="/menu.htm"><i class="fa fa-fw fa-bar-chart-o"></i> 分类管理</a>
      </li>
      <li <?php echo setActive('main');?> >
        <a href="/main.htm"><i class="fa fa-fw fa-bar-chart-o"></i> 数据管理</a>
      </li>
      <li <?php echo setActive('main');?> >
        <a href="/main/poidx.htm"><i class="fa fa-fw fa-bar-chart-o"></i> 推荐管理</a>
      </li>
    </ul>
  </div>
  <!-- /.navbar-collapse -->
</nav>

  <div id="page-wrapper">

    <div class="container-fluid" >

      <!-- Page Heading -->
      <div class="row">
        <div class="col-lg-12">

          <ol class="breadcrumb">
            <li>
              <i class="fa fa-dashboard"></i>数据管理
            </li>
            <li class="active">
              <i class="fa fa-table"></i>数据列表
            </li>
          </ol>
        </div>
      </div>
      <!-- /.row -->
      <div >
        <button  id="button-add" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>添加</button>
      </div>
      <div class="row">
        <div class="col-lg-6">
          <h3></h3>
          <div class="table-responsive">
            <form id="singcms-listorder">
              <table class="table table-bordered table-hover singcms-table">
                <thead>
                <tr>
                  <th width="14">排序</th>
                  <th>分类</th>
                  <th>子分类</th>
                  <th>标题</th>
                  <th>缩略图</th>
                  <th>浏览次数</th>
                  <th>推荐</th>
                  <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php if(is_array($mains)): $i = 0; $__LIST__ = $mains;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?><tr>                   
                    <td><input size=4 type='text'  name='listorder[<?php echo ($data["id"]); ?>]' value="<?php echo ($data["listorder"]); ?>"/></td>
                    <td><?php echo getParentMenuName($data['category'],$menus);?></td>
                    <td><?php echo getParentMenuName($data['sub_category'],$menus);?></td>
                    <td><?php echo ($data["title"]); ?></td>
                    <td><img width="150px" src="<?php echo ($data["thumb"]); ?>"></td>
                    <td><?php echo ($data["count"]); ?></td>
                    <td><span attr-status="<?php if($data['push'] == 1): ?>0<?php else: ?>1<?php endif; ?>"  attr-id="<?php echo ($data["main_id"]); ?>" class="sing_cursor singcms-on-off" id="singcms-on-off" ><?php echo (push($data["push"])); ?></span></td>
                    <td><span class="sing_cursor glyphicon glyphicon-edit" aria-hidden="true" id="singcms-edit" attr-id="<?php echo ($data["main_id"]); ?>" ></span>
                      <a href="javascript:void(0)" id="singcms-delete"  attr-id="<?php echo ($data["main_id"]); ?>"  attr-message="删除">
                        <span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span>
                      </a>
                    </td>
                  </tr><?php endforeach; endif; else: echo "" ;endif; ?>

                </tbody>
              </table>
              <div>
                <button  id="button-listorder" type="button" class="btn btn-primary dropdown-toggle" ><span class="glyphicon glyphicon-resize-vertical" aria-hidden="true"></span>更新排序</button>
              </div>
            </form>
          </div>
        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

  </div>
  <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<script>
  var SCOPE = {
    'edit_url' : '/main/edit.htm',
    'add_url' : '/main/add.htm',
    'set_status_url' : '/main/setStatus.htm',
    'listorder_url' : '/main/listorder.htm',
  }
</script>
<script src="/Public/js/admin/common.js"></script>



</body>

</html>