<?php

return array(
	//'配置项'=>'配置值'
    'URL_HTML_SUFFIX'=>'htm',
    'HTML_FILE_SUFFIX' => '.htm',
    'LOGIN_CHECK_SUCCESS' => '/basic.htm',
    'LOGIN_LOGINOUT_SUCCESS' => '/login',
    'LOGIN_INDEX_SUCCESS' => '/basic',
    'COMMON_INIT_SUCCESS' => '/login',
    'EMPTY_EMPTY_SUCCESS' => 'Index/error',
);