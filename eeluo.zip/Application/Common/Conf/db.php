<?php
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_USER' => 'root',
    'DB_PWD' => '',
    'DB_PORT' => 3306,
    'DB_NAME' => 'eeluo',
    'DB_CHARSET' => 'utf8',
    'DB_PREFIX' =>'eeluo_',
);