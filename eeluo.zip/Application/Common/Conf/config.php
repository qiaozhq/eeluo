<?php
return array(
	//'配置项'=>'配置值'
    'VERSION' =>'1.0',
    'URL_CASE_INSENSITIVE' =>true,
    'URL_MODEL'=>2,
    'URL_HTML_SUFFIX'=>'html',
    'LOAD_EXT_CONFIG' => 'db',
    'MD5_PRE' => 'eeluo_cms',
    'HTML_FILE_SUFFIX' => '.html',
);