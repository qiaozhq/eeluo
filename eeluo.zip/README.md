部署说明
1 关闭debug
2 清除缓存和log